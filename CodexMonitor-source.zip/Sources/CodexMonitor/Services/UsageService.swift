import Foundation

protocol UsageService: Sendable {
    func fetchUsage() async throws -> UsageModel
}

/// Preview-only source, retained for SwiftUI previews and tests.
struct MockUsageService: UsageService {
    func fetchUsage() async throws -> UsageModel {
        try await Task.sleep(for: .milliseconds(350))

        let calendar = Calendar.current
        let now = Date.now
        let expiry = calendar.date(from: DateComponents(year: 2026, month: 8, day: 19)) ?? now

        var weeklyResetComponents = DateComponents()
        weeklyResetComponents.weekday = 2
        weeklyResetComponents.hour = 8
        weeklyResetComponents.minute = 0

        return UsageModel(
            account: "叶少",
            plan: "ChatGPT Plus",
            primaryWindow: UsageWindow(
                title: "5 小时窗口",
                remaining: 72,
                resetTime: calendar.date(byAdding: .hour, value: 2, to: now)
            ),
            secondaryWindow: UsageWindow(
                title: "周额度",
                remaining: 65,
                resetTime: calendar.nextDate(
                    after: now,
                    matching: weeklyResetComponents,
                    matchingPolicy: .nextTime
                )
            ),
            expireDate: expiry,
            lastUpdated: now,
            dataSource: "模拟数据"
        )
    }
}

/// Reads the authenticated account's limits through the locally installed Codex CLI.
/// No token is read, stored, or sent by this app: the CLI performs its own local auth.
struct LiveCodexUsageService: UsageService {
    func fetchUsage() async throws -> UsageModel {
        try await Task.detached(priority: .userInitiated) {
            try CodexAppServerReader.readRateLimits()
        }.value
    }
}

private enum CodexAppServerReader {
    static func readRateLimits() throws -> UsageModel {
        let process = Process()
        process.executableURL = URL(fileURLWithPath: "/usr/bin/env")
        process.arguments = ["codex", "app-server", "--stdio"]
        var environment = ProcessInfo.processInfo.environment
        environment["PATH"] = "\(NSHomeDirectory())/.local/bin:/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin"
        process.environment = environment

        let input = Pipe()
        let output = Pipe()
        process.standardInput = input
        process.standardOutput = output
        process.standardError = Pipe()
        try process.run()

        let initialize = """
        {"jsonrpc":"2.0","id":1,"method":"initialize","params":{"clientInfo":{"name":"Codex Monitor","version":"1.0"}}}
        """
        let readLimits = """
        {"jsonrpc":"2.0","id":2,"method":"account/rateLimits/read","params":null}
        """
        input.fileHandleForWriting.write(Data("\(initialize)\n\(readLimits)\n".utf8))

        // The app server keeps the stream open for notifications. Give the two read-only
        // requests a moment to complete, then end this short-lived query process.
        Thread.sleep(forTimeInterval: 5)
        if process.isRunning { process.terminate() }
        process.waitUntilExit()

        let data = try output.fileHandleForReading.readToEnd() ?? Data()
        return try parseRateLimits(from: data)
    }

    private static func parseRateLimits(from data: Data) throws -> UsageModel {
        let lines = String(decoding: data, as: UTF8.self).split(whereSeparator: \ .isNewline)
        for line in lines {
            guard let data = line.data(using: .utf8),
                  let object = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
                  (object["id"] as? Int) == 2,
                  let result = object["result"] as? [String: Any],
                  let limits = result["rateLimits"] as? [String: Any]
            else { continue }

            let plan = (limits["planType"] as? String)?.capitalized ?? "已登录账户"
            guard let primary = makeWindow(from: limits["primary"] as? [String: Any]) else {
                throw UsageReadError.noLimits
            }
            let secondary = makeWindow(from: limits["secondary"] as? [String: Any])

            return UsageModel(
                account: "当前 Codex 账户",
                plan: plan,
                primaryWindow: primary,
                secondaryWindow: secondary,
                expireDate: nil,
                lastUpdated: .now,
                dataSource: "Codex 实时额度"
            )
        }
        throw UsageReadError.noResponse
    }

    private static func makeWindow(from dictionary: [String: Any]?) -> UsageWindow? {
        guard let dictionary,
              let usedPercent = dictionary["usedPercent"] as? Int
        else { return nil }

        let minutes = dictionary["windowDurationMins"] as? Int
        let resetTime = (dictionary["resetsAt"] as? Double).map(Date.init(timeIntervalSince1970:))
        return UsageWindow(
            title: windowTitle(minutes: minutes),
            remaining: max(0, min(100, 100 - usedPercent)),
            resetTime: resetTime
        )
    }

    private static func windowTitle(minutes: Int?) -> String {
        guard let minutes else { return "额度窗口" }
        if minutes >= 10_080 { return "周额度" }
        if minutes % 60 == 0 { return "\(minutes / 60) 小时窗口" }
        return "\(minutes) 分钟窗口"
    }
}

private enum UsageReadError: LocalizedError {
    case noResponse
    case noLimits

    var errorDescription: String? {
        switch self {
        case .noResponse: "未收到 Codex 用量响应"
        case .noLimits: "当前账户未返回可用额度"
        }
    }
}
