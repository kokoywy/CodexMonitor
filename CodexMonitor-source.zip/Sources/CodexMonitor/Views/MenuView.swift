import SwiftUI

struct MenuView: View {
    @ObservedObject var viewModel: UsageViewModel
    @State private var showsSettings = false

    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            header

            Divider()

            quotaSection(
                title: viewModel.usage.primaryWindow.title,
                remaining: viewModel.usage.primaryWindow.remaining,
                reset: viewModel.usage.primaryWindow.resetTime,
                resetLabel: "重置"
            )

            if let secondary = viewModel.usage.secondaryWindow {
                quotaSection(
                    title: secondary.title,
                    remaining: secondary.remaining,
                    reset: secondary.resetTime,
                    resetLabel: "重置"
                )
            }

            Divider()

            LabeledContent("订阅到期") {
                if let expiry = viewModel.membershipExpiry ?? viewModel.usage.expireDate {
                    Text(expiry, format: .dateTime.year().month().day())
                } else {
                    Text("Codex 未提供")
                }
            }
            .font(.subheadline)

            if let message = viewModel.errorMessage {
                Label(message, systemImage: "exclamationmark.triangle")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }

            HStack {
                Text("最后同步 \(viewModel.usage.lastUpdated, format: .dateTime.hour().minute().second())")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                Spacer()
                Button {
                    WidgetManager.shared.show()
                } label: {
                    Image(systemName: "rectangle.on.rectangle")
                }
                .buttonStyle(.borderless)
                .accessibilityLabel("显示小组件")
                Button {
                    showsSettings = true
                } label: {
                    Image(systemName: "gearshape")
                }
                .buttonStyle(.borderless)
                .accessibilityLabel("设置")
                Button {
                    viewModel.requestRefresh()
                } label: {
                    Image(systemName: viewModel.isRefreshing ? "arrow.triangle.2.circlepath.circle.fill" : "arrow.clockwise")
                }
                .buttonStyle(.borderless)
                .disabled(viewModel.isRefreshing)
                .accessibilityLabel("刷新")
            }
        }
        .padding(16)
        .frame(width: 300)
        .sheet(isPresented: $showsSettings) {
            SettingsView(viewModel: viewModel)
        }
    }

    private var header: some View {
        HStack(spacing: 10) {
            Image(systemName: "gauge.with.dots.needle.67percent")
                .font(.title2)
                .foregroundStyle(.tint)
            VStack(alignment: .leading, spacing: 2) {
                Text("Codex Monitor").font(.headline)
                Text("\(viewModel.usage.account) · \(viewModel.usage.plan) · \(viewModel.usage.dataSource)")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            Spacer()
        }
    }

    private func quotaSection(title: String, remaining: Int, reset: Date?, resetLabel: String) -> some View {
        VStack(alignment: .leading, spacing: 7) {
            HStack {
                Text(title).font(.subheadline.weight(.medium))
                Spacer()
                Text("剩余 \(remaining)%").font(.subheadline.weight(.semibold))
            }
            ProgressBarView(value: remaining)
            HStack {
                Text(resetLabel).foregroundStyle(.secondary)
                Spacer()
                if let reset {
                    Text(reset, format: .dateTime.weekday(.abbreviated).hour().minute())
                } else {
                    Text("未提供")
                }
            }
            .font(.caption)
        }
    }
}

struct SettingsView: View {
    @ObservedObject var viewModel: UsageViewModel
    @State private var hasMembershipExpiry = false
    @State private var membershipExpiry = Date()

    var body: some View {
        Form {
            Section("刷新") {
                Text("用量每 30 分钟自动刷新一次。")
                Button("立即刷新") { viewModel.requestRefresh() }
                    .disabled(viewModel.isRefreshing)
            }
            Section("数据来源") {
                Text("从本机已登录的 Codex App Server 读取当前额度。应用不会读取或保存登录令牌。")
            }
            Section("ChatGPT 会员") {
                Toggle("显示会员到期日", isOn: $hasMembershipExpiry)
                if hasMembershipExpiry {
                    DatePicker("到期 / 下次续费", selection: $membershipExpiry, displayedComponents: .date)
                }
                Text("Codex 不提供该日期。请按 ChatGPT 账户账单页面显示的下次续费日填写。")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
        }
        .formStyle(.grouped)
        .frame(width: 420, height: 340)
        .padding()
        .onAppear {
            if let date = viewModel.membershipExpiry {
                hasMembershipExpiry = true
                membershipExpiry = date
            }
        }
        .onChange(of: hasMembershipExpiry) { _, isEnabled in
            viewModel.setMembershipExpiry(isEnabled ? membershipExpiry : nil)
        }
        .onChange(of: membershipExpiry) { _, date in
            if hasMembershipExpiry { viewModel.setMembershipExpiry(date) }
        }
    }
}
