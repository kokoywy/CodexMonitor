import Foundation

@MainActor
final class RefreshManager {
    private var timer: Timer?

    func start(every interval: TimeInterval = 30 * 60, action: @escaping @MainActor @Sendable () -> Void) {
        stop()
        timer = Timer.scheduledTimer(withTimeInterval: interval, repeats: true) { _ in
            Task { @MainActor in action() }
        }
    }

    func stop() {
        timer?.invalidate()
        timer = nil
    }
}
