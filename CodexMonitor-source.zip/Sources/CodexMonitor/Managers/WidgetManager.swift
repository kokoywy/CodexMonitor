import AppKit
import SwiftUI

@MainActor
final class WidgetManager {
    static let shared = WidgetManager()

    private var panel: NSPanel?
    private var workspaceObserver: NSObjectProtocol?

    private init() {}

    func configure(with viewModel: UsageViewModel) {
        guard panel == nil else { return }

        let panel = NSPanel(
            contentRect: NSRect(x: 0, y: 0, width: 326, height: 380),
            styleMask: [.borderless, .nonactivatingPanel],
            backing: .buffered,
            defer: false
        )
        // A desktop widget should sit behind ordinary app windows instead of
        // following the user across apps and full-screen spaces.
        panel.isFloatingPanel = false
        panel.level = .normal
        panel.collectionBehavior = [.moveToActiveSpace, .transient]
        panel.isOpaque = false
        panel.backgroundColor = .clear
        panel.hasShadow = true
        panel.isMovableByWindowBackground = true
        panel.hidesOnDeactivate = false
        panel.isReleasedWhenClosed = false
        panel.setFrameAutosaveName("CodexMonitorWidget")
        panel.contentView = NSHostingView(rootView: WidgetView(viewModel: viewModel))
        self.panel = panel
        observeWorkspace()
    }

    func show() {
        updateVisibility(for: NSWorkspace.shared.frontmostApplication)
    }

    func hide() {
        panel?.orderOut(nil)
    }

    func toggle() {
        guard let panel else { return }
        panel.isVisible ? hide() : show()
    }

    private func observeWorkspace() {
        workspaceObserver = NSWorkspace.shared.notificationCenter.addObserver(
            forName: NSWorkspace.didActivateApplicationNotification,
            object: nil,
            queue: .main
        ) { [weak self] notification in
            let application = notification.userInfo?[NSWorkspace.applicationUserInfoKey] as? NSRunningApplication
            Task { @MainActor in
                self?.updateVisibility(for: application)
            }
        }
    }

    private func updateVisibility(for application: NSRunningApplication?) {
        guard let panel else { return }
        if application?.bundleIdentifier == "com.apple.finder" {
            panel.orderFront(nil)
        } else {
            panel.orderOut(nil)
        }
    }
}
