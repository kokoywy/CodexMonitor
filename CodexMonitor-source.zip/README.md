# Codex Monitor

一个 macOS 14+ 桌面悬浮小组件，读取本机已登录 Codex 的真实额度、重置时间和套餐，并带有手动/每 30 分钟自动刷新和本地缓存。

## 直接运行（推荐）

双击 `CodexMonitor.app`。应用会在 Finder 桌面上显示一个可拖动的小组件，同时在屏幕顶部右侧菜单栏显示仪表盘图标。切换到其他应用时，小组件会自动隐藏，不会覆盖当前页面；回到桌面时会自动显示。

如果 macOS 首次阻止打开，请在 Finder 中按住 Control 点击应用，选择“打开”。

## 从源码运行

1. 用 Xcode 打开 `Package.swift`（不要直接双击 `Package.swift`；它只是项目配置文件）。
2. 选择 `CodexMonitor` scheme，并将运行目标设为 `My Mac`。
3. 点击 Run（⌘R）。应用会出现在菜单栏；点击仪表盘图标即可查看详情。

也可以在终端中进入本项目目录后运行：

```sh
swift run CodexMonitor
```

首次启动会读取本机 Codex App Server 的 `account/rateLimits/read` 结果；之后最近一次成功获取的数据会保存至 macOS 的 `UserDefaults`。Codex 不返回 ChatGPT 会员到期日，可在小组件的“设置”中填写账单页显示的下次续费日；该日期同样会本地保存。

如修改了源码，在项目目录执行 `Scripts/build-app.sh` 可重新生成 `.app`。

## 项目结构

```
Sources/CodexMonitor/
├── App/        应用与菜单栏入口
├── Models/     用量数据模型
├── Services/   模拟数据源与本地缓存
├── Managers/   自动刷新与视图模型
└── Views/      菜单和进度条界面
```

## 数据来源

默认使用 `LiveCodexUsageService`。它通过本机 `codex app-server --stdio` 查询已登录账户，不会读取、保存或上传登录令牌。
