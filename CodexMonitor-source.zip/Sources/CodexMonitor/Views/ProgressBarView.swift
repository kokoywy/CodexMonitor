import SwiftUI

struct ProgressBarView: View {
    let value: Int
    var tint: Color = .accentColor
    var height: CGFloat = 8

    private var progress: Double {
        Double(min(max(value, 0), 100)) / 100
    }

    var body: some View {
        GeometryReader { proxy in
            ZStack(alignment: .leading) {
                Capsule().fill(.black.opacity(0.10))
                Capsule()
                    .fill(
                        LinearGradient(
                            colors: [tint.opacity(0.72), tint],
                            startPoint: .leading,
                            endPoint: .trailing
                        )
                    )
                    .frame(width: proxy.size.width * progress)
                    .shadow(color: tint.opacity(0.35), radius: 4, y: 1)
            }
        }
        .frame(height: height)
        .accessibilityLabel("剩余 \(value)%")
    }
}
