import Foundation

struct UsageCache {
    private let dataKey = "cachedUsage"
    private let defaults: UserDefaults

    init(defaults: UserDefaults = .standard) {
        self.defaults = defaults
    }

    func load() -> UsageModel? {
        guard let data = defaults.data(forKey: dataKey) else { return nil }
        return try? JSONDecoder().decode(UsageModel.self, from: data)
    }

    func save(_ usage: UsageModel) {
        guard let data = try? JSONEncoder().encode(usage) else { return }
        defaults.set(data, forKey: dataKey)
    }
}
