import Combine
import Foundation

@MainActor
final class UsageViewModel: ObservableObject {
    @Published private(set) var usage: UsageModel
    @Published private(set) var isRefreshing = false
    @Published private(set) var errorMessage: String?
    @Published private(set) var membershipExpiry: Date?

    private let service: any UsageService
    private let cache: UsageCache
    private let refreshManager = RefreshManager()
    private static let membershipExpiryKey = "membershipExpiry"

    init(service: any UsageService = LiveCodexUsageService(), cache: UsageCache = UsageCache()) {
        self.service = service
        self.cache = cache
        self.usage = cache.load() ?? .placeholder
        self.membershipExpiry = UserDefaults.standard.object(forKey: Self.membershipExpiryKey) as? Date
        self.errorMessage = cache.load() == nil ? nil : "显示最近一次缓存记录"
    }

    var menuBarTitle: String {
        usage.account == "—" ? "Codex" : "Codex \(usage.primaryWindow.remaining)%"
    }

    func beginRefreshing() {
        refreshManager.start { [weak self] in
            self?.requestRefresh()
        }
        if usage.account == "—" { requestRefresh() }
    }

    func stopRefreshing() {
        refreshManager.stop()
    }

    func requestRefresh() {
        Task { await refresh() }
    }

    func setMembershipExpiry(_ date: Date?) {
        membershipExpiry = date
        if let date {
            UserDefaults.standard.set(date, forKey: Self.membershipExpiryKey)
        } else {
            UserDefaults.standard.removeObject(forKey: Self.membershipExpiryKey)
        }
    }

    func refresh() async {
        guard !isRefreshing else { return }
        isRefreshing = true
        defer { isRefreshing = false }

        do {
            let result = try await service.fetchUsage()
            usage = result
            cache.save(result)
            errorMessage = nil
        } catch {
            errorMessage = cache.load() == nil
                ? "数据获取失败，请稍后再试"
                : "数据获取失败，显示最近一次记录"
        }
    }
}
