import SwiftUI

struct WidgetView: View {
    @ObservedObject var viewModel: UsageViewModel
    @State private var showsSettings = false

    private let accent = Color(red: 0.35, green: 0.52, blue: 1.0)

    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 24, style: .continuous)
                .fill(.ultraThinMaterial)
                .overlay(alignment: .topTrailing) {
                    Circle()
                        .fill(accent.opacity(0.24))
                        .frame(width: 190, height: 190)
                        .blur(radius: 42)
                        .offset(x: 40, y: -62)
                }

            VStack(alignment: .leading, spacing: 18) {
                header
                primaryQuota

                if let secondary = viewModel.usage.secondaryWindow {
                    secondaryQuota(secondary)
                }

                metadata
                footer
            }
            .padding(18)
        }
        .frame(width: 326)
        .clipShape(RoundedRectangle(cornerRadius: 24, style: .continuous))
        .overlay {
            RoundedRectangle(cornerRadius: 24, style: .continuous)
                .stroke(
                    LinearGradient(
                        colors: [.white.opacity(0.34), .white.opacity(0.08)],
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    ),
                    lineWidth: 1
                )
        }
        .shadow(color: .black.opacity(0.24), radius: 22, y: 12)
        .sheet(isPresented: $showsSettings) {
            SettingsView(viewModel: viewModel)
        }
    }

    private var header: some View {
        HStack(spacing: 10) {
            ZStack {
                RoundedRectangle(cornerRadius: 12, style: .continuous)
                    .fill(accent.gradient)
                Image(systemName: "gauge.with.dots.needle.67percent")
                    .font(.headline.weight(.semibold))
                    .foregroundStyle(.white)
            }
            .frame(width: 38, height: 38)

            VStack(alignment: .leading, spacing: 3) {
                Text("CODEX MONITOR")
                    .font(.caption2.weight(.bold))
                    .tracking(1.1)
                    .foregroundStyle(.secondary)
                Text(viewModel.usage.plan.uppercased())
                    .font(.subheadline.weight(.semibold))
            }

            Spacer()

            HStack(spacing: 5) {
                Circle()
                    .fill(viewModel.usage.dataSource.contains("实时") ? .green : .orange)
                    .frame(width: 6, height: 6)
                Text(viewModel.usage.dataSource.contains("实时") ? "LIVE" : "CACHED")
                    .font(.caption2.weight(.bold))
                    .tracking(0.7)
            }
            .foregroundStyle(.secondary)

            Button { WidgetManager.shared.hide() } label: {
                Image(systemName: "xmark")
                    .font(.caption.weight(.bold))
                    .foregroundStyle(.secondary)
                    .frame(width: 26, height: 26)
                    .background(.quaternary, in: Circle())
            }
            .buttonStyle(.plain)
            .accessibilityLabel("隐藏小组件")
        }
    }

    private var primaryQuota: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack(alignment: .firstTextBaseline) {
                VStack(alignment: .leading, spacing: 3) {
                    Text(viewModel.usage.primaryWindow.title)
                        .font(.subheadline.weight(.medium))
                    Text("当前可用")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                Spacer()
                HStack(alignment: .firstTextBaseline, spacing: 3) {
                    Text("\(viewModel.usage.primaryWindow.remaining)")
                        .font(.system(size: 42, weight: .bold, design: .rounded))
                        .monospacedDigit()
                    Text("%")
                        .font(.title3.weight(.semibold))
                        .foregroundStyle(.secondary)
                }
            }
            ProgressBarView(value: viewModel.usage.primaryWindow.remaining, tint: quotaColor, height: 10)
            resetLine(viewModel.usage.primaryWindow.resetTime)
        }
        .padding(14)
        .background(.black.opacity(0.07), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
    }

    private func secondaryQuota(_ quota: UsageWindow) -> some View {
        HStack(spacing: 12) {
            Image(systemName: "chart.bar.fill")
                .font(.subheadline)
                .foregroundStyle(accent)
                .frame(width: 30, height: 30)
                .background(accent.opacity(0.12), in: RoundedRectangle(cornerRadius: 9, style: .continuous))
            VStack(alignment: .leading, spacing: 4) {
                Text(quota.title).font(.caption.weight(.medium))
                ProgressBarView(value: quota.remaining, tint: accent, height: 6)
            }
            .frame(maxWidth: .infinity)
            Text("\(quota.remaining)%")
                .font(.subheadline.weight(.bold))
                .monospacedDigit()
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 10)
        .background(.black.opacity(0.05), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
    }

    private var metadata: some View {
        HStack(spacing: 10) {
            infoTile(
                icon: "calendar",
                title: "会员续费",
                value: membershipDateText
            )
            infoTile(
                icon: "arrow.triangle.2.circlepath",
                title: "上次同步",
                value: viewModel.usage.lastUpdated.formatted(date: .omitted, time: .shortened)
            )
        }
    }

    private var footer: some View {
        HStack {
            Text(viewModel.usage.account)
                .font(.caption2)
                .foregroundStyle(.secondary)
                .lineLimit(1)
            Spacer()
            Button { showsSettings = true } label: {
                Image(systemName: "slider.horizontal.3")
            }
            .buttonStyle(WidgetIconButtonStyle())
            .accessibilityLabel("设置")
            Button { viewModel.requestRefresh() } label: {
                Image(systemName: viewModel.isRefreshing ? "arrow.triangle.2.circlepath.circle.fill" : "arrow.clockwise")
            }
            .buttonStyle(WidgetIconButtonStyle(highlighted: true))
            .disabled(viewModel.isRefreshing)
            .accessibilityLabel("刷新")
        }
    }

    private var quotaColor: Color {
        switch viewModel.usage.primaryWindow.remaining {
        case 0...20: .red
        case 21...45: .orange
        default: accent
        }
    }

    private var membershipDateText: String {
        guard let expiry = viewModel.membershipExpiry ?? viewModel.usage.expireDate else { return "未设置" }
        return expiry.formatted(.dateTime.month(.twoDigits).day(.twoDigits))
    }

    private func resetLine(_ reset: Date?) -> some View {
        HStack(spacing: 5) {
            Image(systemName: "clock")
            Text("重置：\(resetText(reset))")
            Spacer()
            Text("实时额度")
                .font(.caption2.weight(.medium))
                .padding(.horizontal, 7)
                .padding(.vertical, 3)
                .background(quotaColor.opacity(0.13), in: Capsule())
                .foregroundStyle(quotaColor)
        }
        .font(.caption)
        .foregroundStyle(.secondary)
    }

    private func resetText(_ reset: Date?) -> String {
        guard let reset else { return "未提供" }
        return reset.formatted(.dateTime.weekday(.abbreviated).hour().minute())
    }

    private func infoTile(icon: String, title: String, value: String) -> some View {
        HStack(spacing: 8) {
            Image(systemName: icon)
                .font(.caption.weight(.semibold))
                .foregroundStyle(accent)
                .frame(width: 25, height: 25)
                .background(accent.opacity(0.1), in: RoundedRectangle(cornerRadius: 8, style: .continuous))
            VStack(alignment: .leading, spacing: 2) {
                Text(title).font(.caption2).foregroundStyle(.secondary)
                Text(value).font(.caption.weight(.semibold)).monospacedDigit()
            }
            Spacer(minLength: 0)
        }
        .padding(9)
        .frame(maxWidth: .infinity)
        .background(.black.opacity(0.05), in: RoundedRectangle(cornerRadius: 12, style: .continuous))
    }
}

private struct WidgetIconButtonStyle: ButtonStyle {
    var highlighted = false

    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.caption.weight(.bold))
            .foregroundStyle(highlighted ? .white : .secondary)
            .frame(width: 28, height: 28)
            .background(highlighted ? Color.accentColor : Color.black.opacity(0.07), in: Circle())
            .scaleEffect(configuration.isPressed ? 0.93 : 1)
    }
}
