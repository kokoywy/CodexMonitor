import Foundation

struct UsageWindow: Codable, Equatable, Sendable {
    var title: String
    var remaining: Int
    var resetTime: Date?
}

/// Snapshot returned by the locally authenticated Codex App Server.
struct UsageModel: Codable, Equatable, Sendable {
    var account: String
    var plan: String
    var primaryWindow: UsageWindow
    var secondaryWindow: UsageWindow?
    var expireDate: Date?
    var lastUpdated: Date
    var dataSource: String

    static let placeholder = UsageModel(
        account: "—",
        plan: "—",
        primaryWindow: UsageWindow(title: "额度", remaining: 0, resetTime: nil),
        secondaryWindow: nil,
        expireDate: nil,
        lastUpdated: .now,
        dataSource: "未连接"
    )
}
